package com.example.Pawfect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawfectApplicationTests {

	@Test
	void contextLoads() {
	}

}
