package com.example.Pawfect.service;

import com.example.Pawfect.dto.UserDto;
import com.example.Pawfect.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserMapper userMapper;
    private final BCryptPasswordEncoder passwordEncoder;
    private final EmailVeriService emailVeriService;  // Email 인증 서비스 추가

    // 로그인 - 아이디로 유저 조회
    public UserDto getUserById(String userId) {
        return userMapper.findByUserId(userId);
    }

    // 사용자 인증 후 UserDto 반환 (로그인 성공 시 사용자 정보 가져오기)
    public UserDto authenticateAndGetUser(String userId, String pwd) {
        UserDto user = userMapper.findByUserId(userId); // 사용자 정보를 DB에서 가져옴

        // 사용자 정보가 있고, 비밀번호가 일치하면 사용자 정보 반환
        if (user != null && passwordEncoder.matches(pwd, user.getPwd())) {
            return user; // 인증 성공 시 UserDto 객체 반환
        }

        return null; // 인증 실패 시 null 반환
    }

    // 회원가입
    public void registerUser(UserDto user) {
        // 이메일 인증 확인
        boolean isEmailVerified = emailVeriService.isEmailVerified(user.getEmail());
        if (!isEmailVerified) {
            throw new RuntimeException("이메일 인증이 완료되지 않았습니다.");
        }

        // 비밀번호 암호화
        String encodedPwd = passwordEncoder.encode(user.getPwd()); // 비밀번호 암호화
        user.setPwd(encodedPwd);
        
        // 사용자 등록
        userMapper.insertUser(user);
    }

    // 아이디 중복 체크
    public boolean isUserIdDuplicated(String userId) {
        return userMapper.countByUserId(userId) > 0;
    }

    // 이메일 중복 체크
    public boolean isEmailDuplicated(String email) {
        return userMapper.countByEmail(email) > 0;
    }

    // 아이디 찾기 (이메일로 userId 반환)
    public String findUserIdByEmail(String email) {
        return userMapper.findUserIdByEmail(email);
    }

    // 비밀번호 재설정
    public void resetPassword(String userId, String newPassword) {
        String encodedPwd = passwordEncoder.encode(newPassword);
        userMapper.updatePassword(userId, encodedPwd);
    }
}
