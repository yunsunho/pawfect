package com.example.Pawfect.controller.user;

import com.example.Pawfect.dto.UserDto;
import com.example.Pawfect.service.UserService;
import jakarta.servlet.http.HttpSession; 
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class LoginController {
	private final UserService userService;

	// 로그인 폼
	@GetMapping("/login")
	public String loginForm(@RequestParam(value = "error", required = false) String error,
							@RequestParam(value = "message", required = false) String message, Model model) {
		model.addAttribute("error", error);
		model.addAttribute("message", message);
		return "user/loginForm";
	}

	@PostMapping("/login")
	public String loginSubmit(@RequestParam("userId") String userId, 
	                          @RequestParam("pwd") String pwd, 
	                          HttpServletRequest request, Model model) {
	    // 입력값이 비어있는 경우
	    if (userId == null || userId.trim().isEmpty() || pwd == null || pwd.trim().isEmpty()) {
	        return "redirect:/loginResult?status=failure&error=emptyFields";
	    }

	    // 사용자 인증 처리
	    UserDto user = userService.authenticateAndGetUser(userId, pwd);

	    // DB에 없는 아이디일 경우
	    if (user == null) {
	        return "redirect:/loginResult?status=failure&error=userNotFound";
	    }
	    
	    // 아이디 또는 비밀번호가 틀린 경우 (비밀번호 체크)
	    if (!user.getPwd().equals(pwd)) {
	        return "redirect:/loginResult?status=failure&error=invalidCredentials";
	    }

	    // 계정 상태가 BANNED인 경우
	    if (user.getUserStatus().equals("BANNED")) {
	        return "redirect:/loginResult?status=failure&error=accountBanned";
	    }
	    
	    // 계정 상태가 WITHDRAWN인 경우
	    if (user.getUserStatus().equals("WITHDRAWN")) {
	        return "redirect:/loginResult?status=failure&error=accountWithdrawn";
	    }

	    // 로그인 성공 시 세션에 사용자 정보 저장
	    HttpSession session = request.getSession();  // 세션 가져오기
	    session.setAttribute("loggedInUser", user);  // 사용자 정보 저장

	    // 로그인 성공
	    return "redirect:/loginResult?status=success";
	}
}
