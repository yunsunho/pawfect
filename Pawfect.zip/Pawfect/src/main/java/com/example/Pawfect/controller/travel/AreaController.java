package com.example.Pawfect.controller.travel;

public class AreaController {

}
